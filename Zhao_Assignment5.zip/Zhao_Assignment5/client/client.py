#make a POST request
import requests

while True:
    INPUT = input("Please enter command (Press q or Q to quit)")
    if len(INPUT.split(' '))>=2:
        dictToSend = INPUT.split(' ')[1]
        res = requests.post('http://0.0.0.0:8080/', json=dictToSend)
    else:
        res = requests.get('http://0.0.0.0:8080/')
    if INPUT=="q" or INPUT=="Q":
        break

