import os
from flask import Flask,request,jsonify 
import datetime
from tensorflow import keras
import numpy as np
from keras.preprocessing import image
    
import warnings
warnings.filterwarnings("ignore")

app = Flask(__name__)
PORTNUM = 8080
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)


@app.route("/",methods = ['POST', 'GET'])
def main():
    if request.method == 'POST':
        path= request.data.decode('utf8')
        path = path.replace('"','')
        model = keras.models.load_model('/home/hassan/Desktop/jasonbourne011/server/static/rps.h5')
        img = image.load_img(path, target_size=(150, 150))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)

        images = np.vstack([x])
        label = model.predict_classes(images)
        
        mydate = datetime.datetime.now()
        day= mydate.strftime("%D").split('/')[1]
        month = mydate.strftime("%B")
        year = '20'+mydate.strftime("%D").split('/')[2]
        print("\n\n\n\n\n")
        print("\n\n\n\n\nRock, Paper and Scissors image classification server.")
        print("Jason Bourne")
        print(month +" "+ day, ",",year)
        if label[0]==0:
            print("The image you’ve submitted is classified as a: Paper")
        if label[0]==1:
            print("The image you’ve submitted is classified as a: Rock")
        if label[0]==2:
            print("The image you’ve submitted is classified as a: Scissor")
        
        
        ## Paper 0
        ## Rock 1
        ## Scissor 2

        
    else:

        mydate = datetime.datetime.now()
        day= mydate.strftime("%D").split('/')[1]
        month = mydate.strftime("%B")
        year = '20'+mydate.strftime("%D").split('/')[2]
        print("\n\n\n\n\nRock, Paper and Scissors image classification server.")
        print("Jason Bourne")
        print(month +" "+ day, ",",year)

    return ""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORTNUM)